import pandas as pd

dishes = [
    {"Food Name": "Biryani", "Price": 1800, "Category": "Main Course", "Main Ingredient": "Chicken", "Quantity": 2, "Status": "Available"},
    {"Food Name": "Burger", "Price": 400, "Category": "Fast Food", "Main Ingredient": "Beef", "Quantity": 1, "Status": "Unavailable"},
    {"Food Name": "Pizza", "Price": 900, "Category": "Fast Food", "Main Ingredient": "Cheese", "Quantity": 2, "Status": "Available"},
    {"Food Name": "Pasta", "Price": 600, "Category": "Main Course", "Main Ingredient": "Wheat", "Quantity": 1, "Status": "Available"},
    {"Food Name": "Salad", "Price": 300, "Category": "Appetizer", "Main Ingredient": "Vegetables", "Quantity": 1, "Status": "Available"},
    {"Food Name": "Tacos", "Price": 550, "Category": "Fast Food", "Main Ingredient": "Beans", "Quantity": 2, "Status": "Available"}
]

df = pd.DataFrame(dishes)
print(df)

df["Country"] = "Pakistan"  # assuming same country for all
df["Sale Price"] = df["Price"] * 0.9  # assuming 10% discount
print(df[df["Price"] > 500])
print(df[df["Status"] == "Available"])
print(df[(df["Category"] == "Fast Food") & (df["Status"] == "Available")])
print(df[df["Food Name"] == "Biryani"])
print(df[(df["Price"] > 1500) & (df["Status"] == "Available")])

format_choice = input("(csv/json/excel/xml): ").lower()

if format_choice == "csv":
    df.to_csv("dishes.csv", index=False)
    print("Data saved into dishes.csv")
elif format_choice == "json":
    df.to_json("dishes.json", orient="records")
    print("Data saved into dishes.json")
elif format_choice == "excel":
    df.to_excel("dishes.xlsx", index=False)
    print("Data saved into dishes.xlsx")
elif format_choice == "xml":
    df.to_excel("dishes.xml", index=False)
    print("Data saved into dishes.xml")
else:
    print("Invalid choice.")



