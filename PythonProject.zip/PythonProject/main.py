#Restaurantname = "Delhi Restaurant"
#Address = "North Karachi"
#Speciality = "Chicken Biryani"
#Ph_number = "03132613683"
#City = "Karachi"
#Is_Fivestar = "True"
from tokenize import Special

#print(f"Restaurant Name Is {Restaurantname},\n Located In {Address}.\nSpeciality Is {Speciality}.\n Phone Number Is {Ph_number}.\n City{City}.\n Five Star{Is_Fivestar}")

#Restaurantname = input("Enter Restaurant Name")
#Address = input("Enter Address")
#Speciality = input("Enter Speciality")
#Ph_number = input("Enter ph_number")
#City = input("Enter City")
#Is_Fivestar = input("Enter Rating")

print("Dholo Bholo Halwa Puri Shop")
Puris = int(input("How Many Puri You want"))
Cholay = int(input("How Many Cholay You Want"))
Allu =  int(input("How Many Allu You Want"))
Halwa = int(input("How Many Halwa You Want"))

perpuri = 50
percholay = 100
perallu = 80
perhalwa = 150

totalpuri = 50 * Puris
totalcholay = 100 * Cholay
totalallu = 80 * Allu
totalhalwa = 150 * Halwa

totalbill = totalpuri + totalcholay + totalallu + totalhalwa

tax = totalbill * 0.16
total = tax + totalbill
discount = total * 0.5
bill_after_dis = discount - total
print(f"Total Bill Is : ",totalbill,"\ntax is :", tax, "\n Total is :",total,"\n Discount Is :", discount,
"\nAfterDiscount Total is :",bill_after_dis)